<html lang="en" class="fontawesome-i2svg-active fontawesome-i2svg-complete">

<head>
  <!-- <link rel="stylesheet" href="css/reset1.css">
<link rel="stylesheet" href="css/reset2.css">
<link rel="stylesheet" href="css/reset3.css"> -->
  <link rel="stylesheet" href="css/styles.css">
  <link rel="alternate" media="only screen and (max-width: 640px)" href="./html/FormA.php">
  <!-- <link href="./css/presets.css"> -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Associação de Defesa Animal</title>
  <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
  <!-- Font Awesome icons (free version)-->
  <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>

</head>

<body id="page-top" cz-shortcut-listen="true">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-light fixed-top branco navbar-shrink" id="mainNav">
    <div class="container px-4 px-lg-5">
      <a class="navbar-brand" href="#page-top"></a>
      <a class="mobileButton navbar-toggler navbar-toggler-right pr-2 collapsed" type="button"
        data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive"
        aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <svg class="svg-inline--fa fa-bars" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="bars"
          role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
          <path fill="currentColor"
            d="M0 96C0 78.33 14.33 64 32 64H416C433.7 64 448 78.33 448 96C448 113.7 433.7 128 416 128H32C14.33 128 0 113.7 0 96zM0 256C0 238.3 14.33 224 32 224H416C433.7 224 448 238.3 448 256C448 273.7 433.7 288 416 288H32C14.33 288 0 273.7 0 256zM416 448H32C14.33 448 0 433.7 0 416C0 398.3 14.33 384 32 384H416C433.7 384 448 398.3 448 416C448 433.7 433.7 448 416 448z">
          </path>
        </svg>
        <!-- <i class="fas fa-bars"></i> Font Awesome fontawesome.com -->
      </button>
      <div class="navbar-collapse collapse" id="navbarResponsive">
        <ul class="navbar-nav ms-auto">
          <!--<li class="nav-item"><a class="nav-link" href="#about">Como Ajudar?</a></li> -->
          <a href="#">
            <img src="assets/img/logo.svg" class="logo">
          </a>
          <li class="nav-item">
            <a class="nav-link active" href="#comoAjudar">Como Ajudar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#sobre">Sobre Nós</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#contato">Contato</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="html/animaisadocao.php">Adoção</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="html/animais.php">Animais Memoráveis</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Masthead-->
  <!-- tralei vocÊ >:) -->
  <header class="masthead">
    <div class="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center">
      <div class="d-flex justify-content-center">
        <div class="text-center">
          <h1 class="mx-auto my-0 text-uppercase">Associação de Defesa Animal</h1>
          <h2 class="text-white-50 mx-auto mt-2 mb-5">Sejam Bem-Vindos</h2>
          <a class="btn btn-primary" href="#sobre">Sobre Nós</a>
        </div>
      </div>
    </div>
  </header>
  <!-- About-->
  <section class=" about-section text-center" id="comoAjudar">
    <div class="container px-4 px-lg-5">
      <div class="row gx-4 gx-lg-5 justify-content-center">
        <div class="col-lg-8">
          <h2 class="text-white mb-4">COMO AJUDAR ?</h2>
          <p class="text-white-50">Nossos amiguinhos precisam de todo tipo de ajuda neste momento de tamanha
            crueldade e abandono e
            a
            única coisa que será contagiada é a solidariedade, você pode doar a quantia que seu coração
            mandar e
            ou colaborar trazendo mantimentos em nossa sede (Fauze Kassim 662, Pereira Barreto/SP)
          </p>
          <a id="Rerror" class="btn btn-primary" href="html/ajudar.php">Formas de Ajudar</a>
        </div>
      </div>
      <div class="eita"></div>
    </div>
  </section>


  <!-- SA PORCARIA MALFEITA -->

        <!-- SECTION SOBRE -->
         <section class="min-vh-100" id="sobre" style="padding-top: 30px; height: fit-content;">
          <div class="justify-content-baseline d-flex align-items-stretch flex-column min-h-100">
            <h2 class="text-center text-white">Sobre Nós</h2>
            <div class="row mt-4 d-flex justify-content-around" id="carrossel-animais">
              
              <div class="col d-flex flex-column justify-content-center">
                <img src="assets/pets/shakira.PNG" class="bd-placeholder-img rounded-circle align-self-center animal-img" width="140" height="140" role="img" aria-label="Placeholder" preserveaspectratio="xMidYMid slice" focusable="false">
                <span class="fw-normal text-center text-white text-uppercase">Shakira</span>
              </div>
              
              <div class="col d-flex flex-column justify-content-center">
                <img src="assets/pets/tortinho.png" class="bd-placeholder-img rounded-circle align-self-center animal-img" width="140" height="140" role="img" aria-label="Placeholder" preserveaspectratio="xMidYMid slice" focusable="false">
                <span class="fw-normal text-center text-white text-uppercase">Tortinho</span>
              </div>
              
              <div class="col d-flex flex-column justify-content-center">
                <img src="assets/pets/arisco.PNG" class="bd-placeholder-img rounded-circle align-self-center animal-img" width="140" height="140" role="img" aria-label="Placeholder" preserveaspectratio="xMidYMid slice" focusable="false">
                <span class="fw-normal text-center text-white text-uppercase">Arisco</span>
              </div>
              
              <div class="col d-flex flex-column justify-content-center">
                <img src="assets/pets/principe.PNG" class="bd-placeholder-img rounded-circle align-self-center animal-img" width="140" height="140" role="img" aria-label="Placeholder" preserveaspectratio="xMidYMid slice" focusable="false">
                <span class="fw-normal text-center text-white text-uppercase">Príncipe</span>
              </div>
              
            </div>
            <div class="container-fluid text-justify text-white mt-4 px-auto">
              <p class="h-100">Inicialmente a A.D.A começou com um grupo de mulheres com o objetivo de cuidar dos animais. Logo, esse número se tornou crescente, e hoje, eleita como vereadora, Li Carvalho e demais integrantes da Associação, transformaram o abrigo de animais de rua em uma utilidade pública. Os animais que se encontram no abrigo, são cuidados pelas mãos dos integrantes da A.D.A, animais amorosos. dóceis e companheiros. Estão prontos para dar e receber amor, levando alegria para o lar e compartilhando boas memórias.</p>
            </div>
          </div>
        </section> 

    <!-- Signup -->
  <section class="signup-section" id="contato">
    <div class="container px-4 px-lg-5">
      <div class="row gx-4 gx-lg-5">
        <div class="col-md-10 col-lg-8 mx-auto text-center">
          <svg class="svg-inline--fa fa-paper-plane fa-2x mb-2 text-white" aria-hidden="true" focusable="false"
            data-prefix="far" data-icon="paper-plane" role="img" xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 512 512" data-fa-i2svg="">
            <path fill="currentColor"
              d="M501.6 4.186c-7.594-5.156-17.41-5.594-25.44-1.063L12.12 267.1C4.184 271.7-.5037 280.3 .0431 289.4c.5469 9.125 6.234 17.16 14.66 20.69l153.3 64.38v113.5c0 8.781 4.797 16.84 12.5 21.06C184.1 511 188 512 191.1 512c4.516 0 9.038-1.281 12.99-3.812l111.2-71.46l98.56 41.4c2.984 1.25 6.141 1.875 9.297 1.875c4.078 0 8.141-1.031 11.78-3.094c6.453-3.625 10.88-10.06 11.95-17.38l64-432C513.1 18.44 509.1 9.373 501.6 4.186zM369.3 119.2l-187.1 208.9L78.23 284.7L369.3 119.2zM215.1 444v-49.36l46.45 19.51L215.1 444zM404.8 421.9l-176.6-74.19l224.6-249.5L404.8 421.9z">
            </path>
          </svg>
          <!-- <i class="far fa-paper-plane fa-2x mb-2 text-white"></i> Font Awesome fontawesome.com -->
          <h2 class="text-white mb-5">Solicitar Contato</h2>
          <!-- * * * * * * * * * * * * * * *-->
          <!-- * * SB Forms Contact Form * *-->
          <!-- * * * * * * * * * * * * * * *-->
          <!-- This form is pre-integrated with SB Forms.-->
          <!-- To make this form functional, sign up at-->
          <!-- https://startbootstrap.com/solution/contact-forms-->
          <!-- to get an API token!-->
          <form action="html/php/contact.php" method="POST" class="form-signup" id="contactForm">
              <!-- Email address input-->
              <div class="row input-group-newsletter">
                  <div class="col">
                      <input class="form-control" id="email" type="email" name="email" placeholder="Digite seu Email..."
                          aria-label="Enter email address..." data-sb-validations="required,email"> 
                  </div>
                  <div class="col-auto">
                      <button class="btn btn-primary" id="submitButton" type="submit">Enviar!</button>
                  </div>
              </div>
              <div class="invalid-feedback mt-2" data-sb-feedback="emailAddress:required">An email is required.</div>
              <div class="invalid-feedback mt-2" data-sb-feedback="emailAddress:email">Email is not valid.</div>
              <!-- Submit success message -->
              <!-- This is what your users will see when the form -->
              <!-- has successfully submitted -->
              <div class="d-none" id="submitSuccessMessage"></div>
          </form>

        </div>
      </div>
    </div>
  </section>
  <!-- Contact-->
  <section class="contact-section bg-black" id="contato">
    <div class="container px-4 px-lg-5">
      <div class="row gx-4 gx-lg-5">
        <div class="col-md-4 mb-3 mb-md-0">
          <div class="card py-4 h-100">
            <div class="card-body text-center">
              <svg class="svg-inline--fa fa-map-location-dot text-primary mb-2" aria-hidden="true" focusable="false"
                data-prefix="fas" data-icon="map-location-dot" role="img" xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 576 512" data-fa-i2svg="">
                <path fill="currentColor"
                  d="M408 120C408 174.6 334.9 271.9 302.8 311.1C295.1 321.6 280.9 321.6 273.2 311.1C241.1 271.9 168 174.6 168 120C168 53.73 221.7 0 288 0C354.3 0 408 53.73 408 120zM288 152C310.1 152 328 134.1 328 112C328 89.91 310.1 72 288 72C265.9 72 248 89.91 248 112C248 134.1 265.9 152 288 152zM425.6 179.8C426.1 178.6 426.6 177.4 427.1 176.1L543.1 129.7C558.9 123.4 576 135 576 152V422.8C576 432.6 570 441.4 560.9 445.1L416 503V200.4C419.5 193.5 422.7 186.7 425.6 179.8zM150.4 179.8C153.3 186.7 156.5 193.5 160 200.4V451.8L32.91 502.7C17.15 508.1 0 497.4 0 480.4V209.6C0 199.8 5.975 190.1 15.09 187.3L137.6 138.3C140 152.5 144.9 166.6 150.4 179.8H150.4zM327.8 331.1C341.7 314.6 363.5 286.3 384 255V504.3L192 449.4V255C212.5 286.3 234.3 314.6 248.2 331.1C268.7 357.6 307.3 357.6 327.8 331.1L327.8 331.1z">
                </path>
              </svg>
              <!-- <i class="fas fa-map-marked-alt text-primary mb-2"></i> Font Awesome fontawesome.com -->
              <h4 class="text-uppercase m-0">Endereço</h4>
              <hr class="my-4 mx-auto">
              <div class="small text-black-50">Fauze Kassim 662, Pereira Barreto/SP</div>
            </div>
          </div>
        </div>
        <div class="col-md-4 mb-3 mb-md-0">
          <div class="card py-4 h-100">
            <div class="card-body text-center">
              <svg class="svg-inline--fa fa-envelope text-primary mb-2" aria-hidden="true" focusable="false"
                data-prefix="fas" data-icon="envelope" role="img" xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 512 512" data-fa-i2svg="">
                <path fill="currentColor"
                  d="M464 64C490.5 64 512 85.49 512 112C512 127.1 504.9 141.3 492.8 150.4L275.2 313.6C263.8 322.1 248.2 322.1 236.8 313.6L19.2 150.4C7.113 141.3 0 127.1 0 112C0 85.49 21.49 64 48 64H464zM217.6 339.2C240.4 356.3 271.6 356.3 294.4 339.2L512 176V384C512 419.3 483.3 448 448 448H64C28.65 448 0 419.3 0 384V176L217.6 339.2z">
                </path>
              </svg>
              <!-- <i class="fas fa-envelope text-primary mb-2"></i> Font Awesome fontawesome.com -->
              <h4 class="text-uppercase m-0">Email</h4>
              <hr class="my-4 mx-auto">
              <div class="small text-black-50">
                <a href="mailto:assoc.ada.pb@gmail.com">assoc.ada.pb@gmail.com</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="social d-flex justify-content-center">

      </div>
    </div>
  </section>
  <!-- Footer-->
  <footer class="footer bg-black small text-center text-white-50">
    <div class="container px-4 px-lg-5">Gabriel´s & Audrey Corporation © 2023</div>
  </footer>
  <!-- Bootstrap core JS-->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Core theme JS-->
  <script src="js/scripts.js"></script>
  <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
  <!-- * *                               SB Forms JS                               * *-->
  <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
  <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
  <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>


</body>

</html>