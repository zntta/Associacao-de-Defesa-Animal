<html lang="en"><head>
  <link rel="stylesheet" href="../css/styles.css">
  <link rel="stylesheet" href="../css/style2.css">
  <style>
    body{
      background: url("../assets/img/bg-new.png");
    }
  </style>
  <!-- <a href="../index.php " id="logo"><img src="../assets/img/logo.png" alt=""></a> -->
  <title>Adoção</title>

</head>
<body>
  <form action= "php/enviar.php" method="POST" class="card" style="
    padding: 30px;
">
      <h2>Formulário</h2>
    <div class="mb-3">
    <label for="nome">Nome:</label>
    <input type="nome" id="nome" name="nome" class="form-control" required="">

      <div class="mb-3">
      <label for="telefone">Telefone:</label>
      <input type="number" id="telefone" name="telefone" class="form-control" required="">

        <div class="mb-3">
        <label for="nomeanimal">Nome do Animal:</label>
        <input type="nomeanimal" id="nomeanimal" name="nomeanimal" class="form-control" required="">
    
      <div class="mb-3">
          <label for="email">E-mail:</label>
          <input type="email" id="email" name="email" class="form-control" required="">
      </div>
      <div class="mb-3">

          <label for="data_nascimento">Data de Nascimento:</label>
          <input type="date" id="data_nascimento" name="data_nascimento" class="form-control" required="">
      </div>
      <div class="mb-3">

          <label for="estado">Estado:</label>
          <select id="estado" name="estado" class="form-control" required="">
              <option value="" disabled="" selected="">Selecione seu Estado</option>
              <option value="ac">Acre</option>
              <option value="al">Alagoas</option>
              <option value="ap">Amapá</option>
              <option value="am">Amazonas</option>
              <option value="ba">Bahia</option>
              <option value="ce">Ceará</option>
              <option value="df">Distrito Federal</option>
              <option value="es">Espírito Santo</option>
              <option value="go">Goiás</option>
              <option value="ma">Maranhão</option>
              <option value="mt">Mato Grosso</option>
              <option value="ms">Mato Grosso do Sul</option>
              <option value="mg">Minas Gerais</option>
              <option value="pa">Pará</option>
              <option value="pb">Paraíba</option>
              <option value="pr">Paraná</option>
              <option value="pe">Pernambuco</option>
              <option value="pi">Piauí</option>
              <option value="rj">Rio de Janeiro</option>
              <option value="rn">Rio Grande do Norte</option>
              <option value="rs">Rio Grande do Sul</option>
              <option value="ro">Rondônia</option>
              <option value="rr">Roraima</option>
              <option value="sc">Santa Catarina</option>
              <option value="sp">São Paulo</option>
              <option value="se">Sergipe</option>
              <option value="to">Tocantins</option>
          </select>
      </div>

      <div class="mb-3">
          <label for="cidade">Cidade:</label>
          <input type="text" id="cidade" name="cidade" class="form-control" required="">
      </div>
      <div class="mb-3">
          <label for="cpf">CPF:</label>
          <input type="number" id="cpf" name="cpf" class="form-control" required="" minlength="11" maxlength="11">
      </div>

      <h3>Agora responda algumas perguntas sobre sua residência</h3>
      <div class="mb-3">
          <label for="tipomoradia">Qual o tipo da sua residência ?</label> <br>
          <select id="tipomoradia" name="tipomoradia" class="form-control" required="">
              <option value="">Selecione o Tipo da residência</option>
              <option value="casa">Casa</option>
              <option value="apartamento">Apartamento</option>
              <option value="sitio">Sítio</option>
          </select>
      </div>
      <div class="mb-3">
          <label for="possuiquintal">Possui quintal ?</label><br>

          <div class="form-check">
              <input class="form-check-input" type="radio" name="possuiquintal" id="flexRadioDefault1">
              <label class="form-check-label" for="flexRadioDefault1">
                  Sim
              </label>
          </div>
      </div>
      <div class="mb-3">

          <div class="form-check">
              <input class="form-check-input" type="radio" name="possuiquintal" id="flexRadioDefault2" checked="">
              <label class="form-check-label" for="flexRadioDefault2">
                  Não
              </label>
          </div>
      </div>
      <div class="mb-3">

          <label for="moradiaespacosa">Sua residência é espaçosa?</label><br>

          <div class="form-check">
              <input class="form-check-input" type="radio" name="moradiaespacosa" id="flexRadioDefault3">
              <label class="form-check-label" for="flexRadioDefault1">
                  Sim, muito
              </label>

              <input class="form-check-input" type="radio" name="moradiaespacosa" id="flexRadioDefault4" checked="">
              <label class="form-check-label" for="flexRadioDefault2">
                  Pouco
              </label>

              <input class="form-check-input" type="radio" name="moradiaespacosa" id="flexRadioDefault5" checked="">
              <label class="form-check-label" for="flexRadioDefault3">
                  Não é espaçosa
              </label>
          </div>
      </div>
      <div class="mb-3">

          <label for="trabalha">Você trabalha ?</label><br>
          <div class="form-check">
              <input class="form-check-input" type="radio" name="trabalha" id="flexRadioDefault6">
              <label class="form-check-label" for="flexRadioDefault1">
                  Sim
              </label>
          </div>
          <div class="form-check">
              <input class="form-check-input" type="radio" name="trabalha" id="flexRadioDefault7" checked="">
              <label class="form-check-label" for="flexRadioDefault2">
                  Não
              </label>
          </div>
      </div>
      <div class="mb-3">

          <label for="tempo-fora-casa">Se sim, quanto tempo você fica fora de casa ?</label><br>
          <select id="tempo-fora-casa" name="tempo-fora-casa" class="form-control" required="">
              <option value="dia-todo">O dia todo</option>
              <option value="meio-periodo">Meio período</option>
              <option value="noite-toda">A noite toda</option>
              <option value="home-office">Trabalho Home Office</option>
              <option value="Nenhuma">Nenhuma das opções </option>
          </select>
      </div>
      <div class="mb-3">

          <label for="condicao-financeira">Qual sua condição financeira ?</label><br>
          <select id="condicao-financeira" name="condicao-financeira" class="form-control" required="">
              <option value="menos-de-1000">Menos que 1.000,00</option>
              <option value="acima-de-1000">Acima de 1.000,00</option>
              <option value="acima-de-2000">Acima de 2.000,00</option>
              <option value="acima-de-3000">Acima de 3.000,00 ou mais</option>
          </select>
      </div>
      <div class="mb-3">

          <label for="experiencia-animais">Possui experiência com animais ?</label><br>
          <div class="form-check">
              <input class="form-check-input" type="radio" name="experiencia-animais" id="flexRadioDefault8">
              <label class="form-check-label" for="flexRadioDefault1">
                  Gato
              </label>

              <input class="form-check-input" type="radio" name="experiencia-animais" id="flexRadioDefault9" checked="">
              <label class="form-check-label" for="flexRadioDefault2">
                  Cachorro
              </label>

              <input class="form-check-input" type="radio" name="experiencia-animais" id="flexRadioDefault10" checked="">
              <label class="form-check-label" for="flexRadioDefault3">
                  Ambos
              </label>

              <input class="form-check-input" type="radio" name="experiencia-animais" id="flexRadioDefault11">
              <label class="form-check-label" for="flexRadioDefault1">
                  Não possuo
              </label>
          </div>
      </div>
      <div class="mb-3">

          <input class="form-button btn btn-success" type="submit" value="Enviar Formulário">
          <p>PREENCHA DE FORMA COERENTE, POIS COM ESTE FORMULÁRIO VOCÊ ADOTARÁ SEU AMIGUINHO(A)</p>
      </div>
  </form>

</body>
</html>