<link href="html/index.html"
<head>
    <link rel="alternate" media="only screen and (max-width: 640px)" href="./html/FormA.php">
    <link href="../css/animais.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="styleshee" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>ANIMAIS</title>

    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="../css/styles.css" rel="stylesheet">
    
</head>
<body class="masthead">
  <h4 class="text-white mb-5"> <center>ANIMAIS MEMORÁVEIS DA ASSOCIAÇÃO</center> </h4>

  <div class="container-fluid d-flex justify-content-center align-items-center">
  <div class="card mb-3 w-75">
    <div class="row g-0">
      <div class="col-md-4">
        <img src="../assets/pets/berinjela.jpg" class="img-fluid rounded-start" alt="...">
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h5 class="card-title">Beringela</h5>
          <p class="card-text d-flex h-75 align-items-center justify-content-center">Foi resgatado na feira e recebeu os cuidados necessários da associação, infelizmente sua jornada repleta de carinho e amor chegou ao fim. </p>
          <p class="card-text"><small class="text-body-secondary"></small></p>
        </div>
      </div>
    </div>
  </div>
  </div>

  <div class="container-fluid d-flex justify-content-center align-items-center">
  <div class="card mb-3 w-75">
    <div class="row g-0">
      <div class="col-md-4">
        <img src="../assets/pets/billy.jpg" class="img-fluid rounded-start" alt="...">
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h5 class="card-title">Billy</h5>
          <p class="card-text d-flex h-75 align-items-center justify-content-center">Resgatado pela associação, com deficiência visual, Billy foi muito carinhoso durante sua jornada.</p>
          <p class="card-text"><small class="text-body-secondary"></small></p>
        </div>
      </div>
    </div>
  </div>
  </div>

  <div class="container-fluid d-flex justify-content-center align-items-center">
  <div class="card mb-3 w-75">
    <div class="row g-0">
      <div class="col-md-4">
        <img src="/assets/pets/celine.jpeg" class="img-fluid rounded-start" alt="...">
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h5 class="card-title">Celine</h5>
          <p class="card-text d-flex h-75 align-items-center justify-content-center">Foi resgatada na rodovia pela associação e recebeu o tratamento necessário.</p>
          <p class="card-text"><small class="text-body-secondary"></small></p>
        </div>
      </div>
    </div>
  </div>
  </div>

  <div class="container-fluid d-flex justify-content-center align-items-center">
  <div class="card mb-3 w-75">
    <div class="row g-0">
      <div class="col-md-4">
        <img src="/assets/pets/mansinha.jpeg" class="img-fluid rounded-start" alt="...">
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h5 class="card-title">Mansinha</h5>
          <p class="card-text d-flex h-75 align-items-center justify-content-center">Resgatada em 2018, estava amarrada em um poste sem se quer água, a A.D.A foi acionada e fez o resgate, Mansinha estava com o corpo cheio de feridas, da cabeça as patas, com bichos, foi levada ao abrigo provisório para realizar exames, após ser tratada por 2 meses em outro abrigo, não poderia permanecer ali, foi bem cuidada, mas infelizmente em Dezembro de 2019 obteve um problema no pâncreas e veio a óbito. </p>
          <p class="card-text"><small class="text-body-secondary"></small></p>
        </div>
      </div>
    </div>
  </div>
  </div>

</body>