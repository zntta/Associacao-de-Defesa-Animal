<?php
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $telefone = $_POST['telefone'];
    $nomeanimal = $_POST['nomeanimal'];
    $email = $_POST['email'];
    $datanascimento = $_POST['data_nascimento'];
    $estado = $_POST['estado'];
    $cidade = $_POST['cidade'];
    $cpf = $_POST['cpf'];
    $tipomoradia = $_POST['tipomoradia'];
    $possuiquintal = $_POST['possuiquintal'];
    $moradiaespacosa = $_POST['moradiaespacosa'];
    $trabalho = $_POST['trabalha'];
    $tempoforacasa = $_POST['tempo-fora-casa'];
    $condicaofinanceira = $_POST['condicao-financeira'];
    $experienciaanimais = $_POST['experiencia-animais'];

    $dataenvio = date('d/m/Y');
    $hora_envio = date('H:i:s');

    $arquivo = "
        <html>
            <p><b>Nome: </b>$nome</p>
            <p><b>Telefone: </b>$telefone</p>
            <p><b>Nome do Animal: </b>$nomeanimal</p>
            <p><b>E-mail: </b>$email</p>
            <p><b>Data de Nascimento: </b>$datanascimento</p>
            <p><b>Estado: </b>$estado</p>
            <p><b>Cidade: </b>$cidade</p>
            <p><b>CPF: </b>$cpf</p>
            <p><b>Tipo de Residencia: </b>$tipomoradia</p>
            <p><b>Possui quintal: </b>$possuiquintal</p>
            <p><b>Moradia espacosa: </b>$moradiaespacosa</p>
            <p><b>Tempo no trabalho: </b>$trabalho</p>
            <p><b>Periodo de trabalho: </b>$tempoforacasa</p>
            <p><b>Condicao Financeira: </b>$condicaofinanceira</p>
            <p><b>Experiencia com animais: </b>$experienciaanimais</p>
            <p>Este e-mail foi enviado em <b>$dataenvio</b> às <b>$hora_envio</b></p>
        </html>";

  $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'adaformularios@gmail.com';
        $mail->Password   = 'ucostjcyohfnursi';
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

      // $mail->SMTPDebug = 2;

      
        $mail->setFrom($email, $nome);
        $mail->addAddress('assoc.ada.pb@gmail.com');
        $mail->isHTML(true);
        $mail->Subject = 'Adotar';
        $mail->Body    = $arquivo;

        $mail->send();
        echo '<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página com Vídeo de Background</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            overflow: hidden;
            font-family: Arial, sans-serif;
        }

        #video-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            /* Cobrir completamente a tela mantendo a proporção */
            z-index: -1000;
        }

        #content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: #fff;
        }

        h1 {
            font-size: 3em;
            margin-bottom: 0.5em;
        }

        p {
            font-size: 1.5em;
            margin: 0;
        }

        #notification-card {
            position: fixed;
            top: 20px;
            left: 20px;
            max-width: 300px;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.8);
            color: #fff;
            border-radius: 8px;
            display: none;
            z-index: 1000;
        }

        #notification-card.show {
            display: block;
        }
    </style>
</head>

<body>

    <!-- Vídeo de Background -->
    <video id="video-background" autoplay="" muted="" loop="">
        <source src="fundo.mp4" type="video/mp4">
        Seu navegador não suporta o elemento de vídeo.
    </video>

    <!-- Notificação de Email Enviado -->
    <div id="notification-card" class="show">
        <h1>Email Enviado com Sucesso</h1>
        <p>Redirecionando para a página inicial...</p>
    </div>

    <script>
        // Simula o envio do email com sucesso
        setTimeout(function () {
            // Mostra a mensagem
            document.getElementById("notification-card").classList.add("show");
        });
    </script>



</body>

</html>';
    } catch (Exception $e) {
        echo "Erro ao enviar o e-mail. Mensagem de erro: {$mail->ErrorInfo}";
    }
} else {
    echo 'Erro: Método inválido.';
}
echo ('<meta http-equiv="refresh" content="5; url=http://ada.nuloux.repl.co">');
?>