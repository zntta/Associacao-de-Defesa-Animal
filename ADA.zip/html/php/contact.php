<?php
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Carregue as classes PHPMailer e SMTP usando o autoload do Composer
// Remova os requires manuais, pois o Composer já cuida disso

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    $arquivo = "
        <html>
            <p>Pediu para entrar em contato <b>E-mail: </b>$email</p>
        </html>";

    try {
        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'adaformularios@gmail.com';
        $mail->Password   = 'ucostjcyohfnursi';
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        // Defina o modo de depuração apenas se estiver em desenvolvimento
        // Remova isso na produção para evitar a exposição de informações sensíveis
        // $mail->SMTPDebug  = 2;

        $mail->setFrom($email);
        $mail->addAddress('assoc.ada.pb@gmail.com');
        $mail->isHTML(true);
        $mail->Subject = 'Contato';
        $mail->Body    = $arquivo;

        $mail->send();
              echo '<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página com Vídeo de Background</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            overflow: hidden;
            font-family: Arial, sans-serif;
        }

        #video-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            /* Cobrir completamente a tela mantendo a proporção */
            z-index: -1000;
        }

        #content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: #fff;
        }

        h1 {
            font-size: 3em;
            margin-bottom: 0.5em;
        }

        p {
            font-size: 1.5em;
            margin: 0;
        }

        #notification-card {
            position: fixed;
            top: 20px;
            left: 20px;
            max-width: 300px;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.8);
            color: #fff;
            border-radius: 8px;
            display: none;
            z-index: 1000;
        }

        #notification-card.show {
            display: block;
        }
    </style>
</head>

<body>

    <!-- Vídeo de Background -->
    <video id="video-background" autoplay="" muted="" loop="">
        <source src="fundo.mp4" type="video/mp4">
        Seu navegador não suporta o elemento de vídeo.
    </video>

    <!-- Notificação de Email Enviado -->
    <div id="notification-card" class="show">
        <h1>Email Enviado com Sucesso</h1>
        <p>Redirecionando para a página inicial...</p>
    </div>

    <script>
        // Simula o envio do email com sucesso
        setTimeout(function () {
            // Mostra a mensagem
            document.getElementById("notification-card").classList.add("show");
        });
    </script>



</body>

</html>';
    } catch (Exception $e) {
        echo "Erro ao enviar o e-mail. Mensagem de erro: {$mail->ErrorInfo}";
    }
} else {
    echo 'Erro: Método inválido.';
}

echo ('<meta http-equiv="refresh" content="5; url=http://ada.nuloux.repl.co">');
?>
