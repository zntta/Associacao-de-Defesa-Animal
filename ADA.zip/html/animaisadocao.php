<html><head>
    <link rel="stylesheet" href="../css/animaisadocao.css" <link="">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
 </head><body><meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>ADOÇÃO DE ANIMAIS</title>


<header style="
    padding: 10px;
    display: flex;
    justify-content: flex-end;
">
  <a href="../html/FormA.php" class="form-button btn btn-success" type="submit" value="Formulário" style="
    padding: mar;
">
  Formulário </a> 
</header>
<a href="../index.php" class="back-button" onclick="history.go(-1);" style="position:absolute;top: -3.1px;">Voltar</a>
    <section class="container-fluid">

        <div class="d-flex align-items-center justify-content-center flex-column">
            <!-- INICIO DO PHP -->
            <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

            <!-- CARDS LISTANDO ANIMAIS -->
            <div class="card my-3 rounded-3 p-3 w-75" id="1">
                <div class="row g-0">
                    <!-- Imagem -->
                    <div class="col-md-4 shadow animal-img animal-img" style="
    background: url(/assets/pets/tortinho.png) no-repeat;
    border-radius: 24px;
    display: flex;
    justify-content: center;
    align-content: center;
    flex-wrap: wrap;
    background-position: center;
    background-size: cover;
">

                    </div>

                    <!-- Textos -->
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title text-justify">
                                Tortinho </h5>
                            <div class="card-text">
                                <span class="badge text-bg-success">
                                    Disponível </span>
                            </div>
                            <p class="card-text">Achado no meio de uma pista com a pata quebrada depois de diversos
                                dias, que infelizmente teve que ser amputada. O Tortinho ama abraçar, é um animal
                                extrovertido e brincalhão.</p>
                        </div>
                        <div class="card-body">
                            <ul class="w-100 d-flex flex-wrap justify-content-around" style="
">
                                <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    border-radius: 24px;
    background: url(/assets/pets/principe.PNG) no-repeat;
    background-position: center;
    background-size: cover;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Príncipe </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Encontrado em um rancho e alimentado por pessoas que viviam na
                                    região, Príncipe teve o prazer de ser adotado pela associação. Infelizmente tem
                                    dificuldades para se locomover, adora carinhos e é muito dócil.</p>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled w-100 d-flex flex-wrap justify-content-around">
                                    <li class="me-3"><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class="me-3"><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class="me-3"><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    border-radius: 24px;
    background: url(/assets/pets/tulio.PNG) no-repeat;
    background-size: cover;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Túlio </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Vagando por dias sozinho na cidade, foi resgatado e levado ao
                                    abrigo, Túlio adora brincar e receber atenção de quem passa por ele.</p>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled w-100 d-flex flex-wrap justify-content-around">
                                    <li class="me-3"><span class="fw-bold badge text-bg-secondary">MACHO</span></li>
                                    <li class="me-3"><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class="me-3"><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    border-radius: 24px;
    background: url(/assets/pets/zezinho.PNG) no-repeat;
    background-size: cover;
    background-position: top;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Zezinho </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Zezinho foi abandonado e apareceu na porta da associação, onde
                                    prontamente foi acolhido e cuidado, ama brincar e receber carinho daqueles que vê.
                                </p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    border-radius: 24px;
    background: url(/assets/pets/nikita.PNG) no-repeat;
    background-position: unset;
    background-size: cover;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Nikita </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Nikita foi adotada pela associação depois que sua ex-dona não tinha
                                    mais condições de cuidar, um cachorro companheiro e que gosta de brincar.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    border-radius: 24px;
    background: url(/assets/pets/estopinho.PNG) no-repeat;
    background-size: cover;
    background-position: center;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Estopinho </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Abandonado e por diversos dias sozinho na rua, chegou na associação
                                    muito debilitado e hoje está saudável e esperando por sua adoção. </p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/alemao.PNG) no-repeat;
    background-size: cover;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Alemão </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Alemão foi abandonado em um thermas, e logo após foi resgatado por
                                    um dos membros da associação. Hoje está saudável e procurando por um dono.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/thor.PNG);
    background-size: cover;
    background-position: initial;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Thor </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Ele foi resgatado por um dos membros da associação, em uma casa da
                                    qual não era bem cuidado, não andava mais, foi realizado o procedimento da
                                    acupuntura e ele voltou a andar. Um animal muito calmo e amoroso.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/florzinha.PNG) no-repeat;
    background-size: cover;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Florzinha </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Foi recolhida na praia onde foi abandonada e a associação prestou
                                    seus serviços para o cuidado e bem-estar do animal. Muito meiga e calma, espera por
                                    sua adoção!</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/estrela.PNG) no-repeat;
    background-size: cover;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Estrela </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Estrela foi recolhida na praia, depois de sofrer abandono por seus
                                    antigos donos. Brincalhona e extrovertida, adora carinho.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    border-radius: 24px;
    background: url(/assets/pets/captu.PNG) no-repeat;
    background-size: cover;
    background-position: top;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Captu </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Morava em uma lava-jato e foi adotada pela associação, recebeu os
                                    cuidados necessários e todo o carinho que precisava. Muito alegre e brincalhona.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/getulio.PNG) no-repeat;
    background-size: cover;
    background-position: center;
    border-radius: 25px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Getulio </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Espancado pelo dono, Getulio foi resgatado pela associação e
                                    acolhido, recebendo os cuidados necessários com muita dedicação e amor.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/marquinha.PNG) center no-repeat;
    /* background-size: cover; */
    /* background-position: revert; */
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Marquinha </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Encontrada na pista depois de um atropelamento, Marquinha também
                                    foi um dos animais resgatados pela associação.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/dona.PNG);
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Dona </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Abandonada na pista e encontrada por um morador dali, foi levada
                                    até a associação e logo recebeu o suporte e ajuda necessária.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/menina.PNG);
    background-position: bottom;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Menina </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Foi encontrada em um rancho, bem delimitada e posteriormente
                                    acolhida pela associação. Muito animada e bagunceira, adora quem a visita.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    border-radius: 24px;
    background: url(/assets/pets/mozao.PNG);
    background-position: center;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Mozão </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Encontrada em um terreno baldio em um dia de chuva, muito tímida e
                                    medrosa, foi cuidada pela associação.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/marrom.PNG);
    border-radius: 24px;
    background-position: bottom;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Marrom </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Encontrado bem debilitado em frente ao hospital, foi recebido pela
                                    associação e realizou os procedimentos necessários para sua saúde.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/gigi.PNG);
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Gigi </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Resgatada na praia pela associação, Gigi recebeu o tratamento
                                    necessário o qual precisava.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    border-radius: 24px;
    background: url(/assets/pets/joao.PNG) center;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    João </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Encontrado na rua a qual estava há dias, foi acolhido pela
                                    associação e recebeu o amor e carinho que precisava.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/lampiao.PNG) center;
    background-position: bottom;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Lampião </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Lampião
                                    Filhote de uma das cachorrinhas da associação.
                                </p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    border-radius: 24px;
    background: url(/assets/pets/maezinha.PNG) center;
    background-position: revert;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Mãezinha </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Foi resgatada no lixão pela associação, cuidada e alimentada,
                                    recebendo todo o cuidado que precisava.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    border-radius: 24px;
    background: url(/assets/pets/mi.PNG);
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Mi, Bonitão e Bonitniho </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Todos resgatados pela associação, recebendo todos os cuidados
                                    necessários</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA, MACHO, MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/arisco.PNG);
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Arisco </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Acolhido pela associação, é muito medroso e tímido</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/shakira.PNG) center no-repeat;
    border-radius: 24px;
    background-size: cover;
    background-position: right;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Shakira </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Morava em um hospital e como não era permitido animais, foi
                                    recolhida pela associação, recebendo atenção e cuidado. Muito meiga e carinhosa</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    border-radius: 24px;
    background: url(/assets/pets/primeiro.PNG) center no-repeat;
    background-size: cover;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Primeiro </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Foi encontrado no canal amarrado durante 3 dias, foi resgatado pela
                                    associação e recebeu os cuidados necessários.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/filhote2.PNG) center no-repeat;
    background-size: cover;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Filhote 2 </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Nasceram na associação, após a mãe ser resgatada.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/filhote3e4.PNG) center no-repeat;
    background-size: cover;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Filhote 3 e 4</h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Nasceram na associação, após a mãe ser resgatada.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/filhote5.PNG) center no-repeat;
    background-size: cover;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Filhote 5 </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Filhote da Captu</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/bela.PNG) center no-repeat;
    background-size: cover;
    background-position: center;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Bela </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Foi atropelada e deixada no local, depois foi entregue para a
                                    associação com uma pata quebrada, recebeu o acolhimento necessário.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/duque.PNG) center no-repeat;
    border-radius: 24px;
    background-size: cover;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Duque </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Um cachorro do canil, Duque foi adotado, sofria maus tratos e foi
                                    recolhido e cuidado pela associação.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/cristal.PNG) center no-repeat;
    background-size: cover;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Cristal </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Encontrada na praia, acabou por dar cria e foi resgatada pela
                                    associação, junto a seus filhotes.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/lua.PNG) center;
    background-size: cover;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Lua </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Encontrada na praia, acabou por dar cria e foi resgatada pela
                                    associação, junto a seus filhotes.
                                </p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/princesa.PNG) center no-repeat;
    background-size: cover;
    background-position: right;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Princesa </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Morava no canil, foi para adoção e após não ter sido adotada veio
                                    para a associação e recebeu todo amor e carinho que necessitava.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/tete.PNG) no-repeat;
    border-radius: 24px;
    background-size: cover;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Tete </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Foi resgatada grávida de seus filhotes e fizeram seu parto por
                                    cesárea, onde logo após nasceram seus filhotes.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/oreo.PNG) center no-repeat;
    background-size: cover;
    background-position: center;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Oreo </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Resgatado no meio da mata pela associação e recebeu os cuidados
                                    necessários.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="background: url(/assets/pets/zelda.PNG) center no-repeat;background-size: cover;background-position: center;border-radius: 24px;">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Zelda </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Resgatado no meio da mata pela associação e recebeu os cuidados
                                    necessários.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/negao.PNG) center no-repeat;
    background-size: cover;
    border-radius: 24px;
    background-position: center;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Negão </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Morava na rua, encontrado machucado e debilitado, foi resgatado
                                    pela associação e recebeu os cuidados necessários.</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>MACHO</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/lindinha.PNG) center no-repeat;
    background-size: cover;
    background-position: center;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Lindinha </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Resgatada da rua e levada para receber cuidados na associação</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container-fluid">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <!-- INICIO DO PHP -->
                <!-- ESTRUTURA DE INSERÇÃO DOS DADOS NA TABELA -->

                <!-- CARDS LISTANDO ANIMAIS -->
                <div class="card my-3 rounded-3 p-3 w-75" id="1">
                    <div class="row g-0">
                        <!-- Imagem -->
                        <div class="col-md-4 shadow animal-img" style="
    background: url(/assets/pets/florzinha2.PNG) center no-repeat;
    background-size: cover;
    background-position: left;
    border-radius: 24px;
">

                        </div>

                        <!-- Textos -->
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title text-justify">
                                    Florzinha (2) </h5>
                                <div class="card-text">
                                    <span class="badge text-bg-success">
                                        Disponível </span>
                                </div>
                                <p class="card-text">Resgatada da rua e levada para receber cuidados na associação</p>
                            </div>
                            <div class="card-body">
                                <ul class="w-100 d-flex flex-wrap justify-content-around">
                                    <li class=""><span class="fw-bold">Sexo: </span>FEMEA</li>
                                    <li class=""><span class="fw-bold">Raça: </span>Sem Raça Definida</li>
                                    <li class=""><span class="fw-bold">Vacinação: </span>EM DIA</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>




    </section>


</body></html>