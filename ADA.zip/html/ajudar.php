<!DOCTYPE html>
<html lang="pt-BR">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
  integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<head>
  <meta charset="UTF-8">
  <title>Formas de Ajudar </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background: url("../assets/img/bg-new.png");
    }

    header {
      background-color: #fff;
      padding: 20px;
      text-align: start;
      display: flex;
      justify-content: center;
      box-shadow: 0 0 9px black;
    }

    .back-button {
      background-color: rgba(32, 96, 138, 0.575)b2;
      color: #64a19d;
      padding: 10px 20px;
      border-radius: 5px;
      text-decoration: none;
      margin: 10px;
      box-shadow: 0px 0px 124px 0px black;
    }

    .back-button:hover {
      background-color: #888888;
      box-shadow: 0px 0px 4px 0px black;
    }

    .container {
      width: 37%;
      text-align: center;
      margin-top: 4%;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
  @media (max-width: 699px) {
    .container {
      width: 90%;
    }
  }

    @media (max-width: 1300px) {
      .container {
        width: 50%;
      }
    }

    @media (max-width: 800px) {
      .container {
        width: 90%;
      }
    }

    #qrcode {
      width: 250px;
      height: 250px;
      margin: 20px auto;
    }
  </style>
</head>

<body>
  <header>
    <h1>Formas de Ajudar </h1>
  </header>
    <a href="../index.php" class="back-button" onclick="history.go(-1);" style="position:absolute; top:1%;">Voltar</a>

  <div class="container card">
    <h1>QR Code - Doação via Pix</h1>
    <div id="qrcode"></div>
  </div>

  <script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
  <script>
    const qrText = "00020126360014BR.GOV.BCB.PIX0114274566590001035204000053039865802BR5905Adapb6015Pereira Barreto62100506DOACAO6304D2A7";
    const qrcode = new QRCode(document.getElementById("qrcode"), {
      text: qrText,
      width: 250,
      height: 250
    });
  </script>

</body>

</html>